const Joi = require("joi");
const Item = require("../model/item");

const ItemSchema = Joi.object({
	name: Joi.string().required(),
	description: Joi.string().required(),
	price: Joi.number().required(),
	qty: Joi.number(),
	itemSrc: Joi.string(),
});

const addItem = async (req, res) => {
	const { error } = ItemSchema.validate(req.body);
	console.log(req.user);
	if (error) {
		return res
			.status(400)
			.json({ Error: true, Message: error.details[0].message });
	}
	const { name, description, price, qty, itemSrc } = req.body;

	try {
		const newItem = new Item({
			name,
			description,
			price,
			seller: req.user._id,
			qty,
			itemSrc,
		});
		await newItem.save();

		return res.status(201).json({
			Error: false,
			Message: "Item added successfully",
			item: newItem,
		});
	} catch (error) {
		console.error("Error in adding item:", error);
		return res
			.status(500)
			.json({ Error: true, Message: "Internal server error" });
	}
};

const startBidding = async (req, res) => {
	const { itemId } = req.params;
	try {
		const item = await Item.findOneAndUpdate(
			{ _id: itemId, seller: req.user._id },
			{ IsBidding: true },
			{ new: true },
		);
		if (!item) {
			return res.status(404).json({ Error: true, Message: "Item not found" });
		}
		return res
			.status(200)
			.json({ Error: false, Message: "Bidding started for the item", item });
	} catch (error) {
		console.error("Error in starting bidding:", error);
		return res
			.status(500)
			.json({ Error: true, Message: "Internal server error" });
	}
};

const getBiddingItems = async (req, res) => {
	try {
		const items = await Item.find({ IsBidding: true, qty: { $gt: 0 } });
		return res.status(200).json({ Error: false, Items: items });
	} catch (error) {
		console.error("Error in getting bidding items:", error);
		return res
			.status(500)
			.json({ Error: true, Message: "Internal server error" });
	}
};

module.exports = { addItem, startBidding, getBiddingItems };
