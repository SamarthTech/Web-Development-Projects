const express = require("express");
const { checkUserAuth } = require("../middlewares/auth-middleware");
const { placeBid } = require("../controller/bidController");

const route = express.Router();

route.post("/place-bid", checkUserAuth, placeBid);
module.exports = route;
