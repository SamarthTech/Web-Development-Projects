const express = require("express");
const {
	addItem,
	startBidding,
	getBiddingItems,
} = require("../controller/ItemController");
const { checkUserAuth } = require("../middlewares/auth-middleware");
const route = express.Router();

route.get("/", getBiddingItems);
route.post("/add", checkUserAuth, addItem);
route.post("/start-bid/:itemId", checkUserAuth, startBidding);

module.exports = route;
